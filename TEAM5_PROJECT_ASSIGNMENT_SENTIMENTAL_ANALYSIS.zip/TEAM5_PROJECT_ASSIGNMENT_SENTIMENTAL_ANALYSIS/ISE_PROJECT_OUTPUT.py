Python 3.10.4 (tags/v3.10.4:9d38120, Mar 23 2022, 23:13:41) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

Warning (from warnings module):
  File "C:\Users\nspra\AppData\Local\Programs\Python\Python310\commits_from_all_repos_code.py", line 19
    df=df.append(d,ignore_index=True)
FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.

================================ RESTART: C:\Users\nspra\AppData\Local\Programs\Python\Python310\TEAM_5_ISE_SENTIMENT.py ================================
------------------------------------------------------------------------- Cleaned data---------------------------------------------------------------
0       Merge pull request #183 from bkeepers/unmainta...
1                                          clarify status
2       Fix Tempfile usage under ruby 1.8.7\r\n\r\nThe...
3       Merge pull request #157 from github/atomic-obj...
4       fsync loose objects before moving into place\r...
                              ...                        
2149                                  remove unused files
2150                                       Updated readme
2151                         They changed the date on us!
2152                               Small update to readme
2153                         Added a CSS Naked Day plugin
Name: Cleaned_messages, Length: 2154, dtype: object
-----------------------------------------------------------------------------POS_tagged--------------------------------------------------------------
0       [(Merge, n), (pull, a), (request, n), (#, None...
1                             [(clarify, n), (status, n)]
2       [(Fix, n), (Tempfile, n), (usage, n), (ruby, n...
3       [(Merge, n), (pull, a), (request, n), (#, None...
4       [(fsync, n), (loose, a), (objects, n), (moving...
                              ...                        
2149               [(remove, v), (unused, a), (files, n)]
2150                          [(Updated, v), (readme, n)]
2151     [(changed, v), (date, n), (us, None), (!, None)]
2152               [(Small, a), (update, n), (readme, v)]
2153    [(Added, v), (CSS, n), (Naked, n), (Day, n), (...
Name: POS_tagged, Length: 2154, dtype: object
--------------------------------------------------------------------------------Lemma----------------------------------------------------------------
0         Merge pull request # 183 bkeepers/unmaintain...
1                                          clarify status
2         Fix Tempfile usage ruby 1.8.7 's third argum...
3         Merge pull request # 157 github/atomic-objec...
4         fsync loose object move place write loose ob...
                              ...                        
2149                                   remove unused file
2150                                       Updated readme
2151                                     change date us !
2152                                  Small update readme
2153                           Added CSS Naked Day plugin
Name: Lemma, Length: 2154, dtype: object
---------------------------------------------------------------------------------Polarity------------------------------------------------------------
0        1.0
1        0.0
2        5.0
3        0.0
4      -19.0
        ... 
2149     0.0
2150     0.0
2151     0.0
2152     0.0
2153     0.0
Name: Polarity, Length: 2154, dtype: float64
---------------------------------------------------------------------------------Analysis------------------------------------------------------------
0       Positive
1        Neutral
2       Positive
3        Neutral
4       Negative
          ...   
2149     Neutral
2150     Neutral
2151     Neutral
2152     Neutral
2153     Neutral
Name: Analysis, Length: 2154, dtype: object
---------------------------------------------------------------------------Analysis Observations-----------------------------------------------------
Neutral     1462
Positive     438
Negative     254
Name: Analysis, dtype: int64
