from textblob import TextBlob
import re
import pandas as pd
import re
from afinn import Afinn
import shutup
import nltk
from nltk.tokenize import word_tokenize
from nltk import pos_tag
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk.stem import WordNetLemmatizer
wordnet_lemmatizer = WordNetLemmatizer()
from nltk.stem import WordNetLemmatizer
wordnet_lemmatizer = WordNetLemmatizer()


mydata=pd.read_csv("commit_results.csv")
mydata['Cleaned_messages'] = mydata['messages']
print("------------------------------------------------------------------------- Cleaned data---------------------------------------------------------------")
print(mydata.Cleaned_messages)


pos_dict = {'J':wordnet.ADJ, 'V':wordnet.VERB, 'N':wordnet.NOUN, 'R':wordnet.ADV}
def token_stop_pos(text):
    tags = pos_tag(word_tokenize(text))
    newlist = []
    for word, tag in tags:
        if word.lower() not in set(stopwords.words('english')):
           newlist.append(tuple([word, pos_dict.get(tag[0])]))
    return newlist
mydata['POS_tagged'] = mydata['Cleaned_messages'].apply(token_stop_pos)
print("-----------------------------------------------------------------------------POS_tagged--------------------------------------------------------------")
print(mydata.POS_tagged)

def lemmatize(pos_data):
    lemma_rew = " "
    for word, pos in pos_data:
        if not pos:
            lemma = word
            lemma_rew = lemma_rew + " " + lemma
        else:
            lemma = wordnet_lemmatizer.lemmatize(word, pos=pos)
            lemma_rew = lemma_rew + " " + lemma
    return lemma_rew

mydata['Lemma'] = mydata['POS_tagged'].apply(lemmatize)
print("--------------------------------------------------------------------------------Lemma----------------------------------------------------------------")
print(mydata.Lemma)

def getPolarity(mydata):
    afinn = Afinn(emoticons=True)
    score = afinn.score(mydata)
    return score    
def analysis(score):
    if score < 0:
        return 'Negative'
    elif score == 0:
        return 'Neutral'
    else:
        return 'Positive'
fin_data = pd.DataFrame(mydata[['Cleaned_messages','Lemma']])
fin_data['Polarity'] = fin_data['Lemma'].apply(getPolarity) 
fin_data['Analysis'] = fin_data['Polarity'].apply(analysis)
print("---------------------------------------------------------------------------------Polarity------------------------------------------------------------")
print(fin_data.Polarity)
print("---------------------------------------------------------------------------------Analysis------------------------------------------------------------")
print(fin_data.Analysis)

total_counts = fin_data.Analysis.value_counts()
print("---------------------------------------------------------------------------Analysis Observations-----------------------------------------------------")
print(total_counts)
