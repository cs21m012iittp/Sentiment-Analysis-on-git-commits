import requests
import json
import csv
import pandas as pd
from pprint import pprint

df=pd.DataFrame(columns=["messages"])
url = f"https://api.github.com/repositories"
uname="NSPragna"
token1="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"
token2="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"
user_data = requests.get(url,auth=(uname,token1)).json()
for x in user_data:
    b=x['url']
    url1=f"{b}/commits"
    com_data=requests.get(url1,auth=(uname,token2)).json()
    for y in com_data:
        d={'messages':y['commit']['message']}
        df=df.append(d,ignore_index=True)
    df.to_csv("commit_results.csv",index=False)    
        # pprint(y['commit']['message'])
         
