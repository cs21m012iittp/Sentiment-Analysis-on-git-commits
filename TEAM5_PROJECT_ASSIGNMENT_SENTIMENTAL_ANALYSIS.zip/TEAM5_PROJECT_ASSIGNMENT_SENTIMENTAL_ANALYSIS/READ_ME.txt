Contributed by N.Sai Pragna and M.Mithlesh Kumar

-->Here we tried to implement sentimental analysis on github commits.
-->Here we extracted commit messages from git commits using git api and perform sentimental analysis using ntlk python library.